# -*- coding: utf-8 -*-
from flask import Flask, render_template, jsonify, request
from time import sleep
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.trainers import ListTrainer

def fun(input_txt):
	response = chatbot.get_response(input_txt)
	return str(response)


app = Flask(__name__)

@app.route('/')
def index_page():
    return render_template('index.html')

@app.route('/respond', methods=['GET','POST'])
def respond():
    sleep(1)
    input_txt = request.form['message']
    res = fun(input_txt)
    return jsonify({ 'response': res })
    # return jsonify({ 'response': 'i don\'t know' })


if __name__ == '__main__':
	chatbot = ChatBot("myBot")
	chatbot.set_trainer(ChatterBotCorpusTrainer)
	chatbot.train(
    "./data/my_corpus/"
	)
	app.run(port=8000)
    # app.run('https://eunice730711.github.io/resume_chatbot/')


